<?php
/**
 * 支付宝支付
 */

return [
        //应用ID,您的APPID。
        'app_id' => "2017101709352598",

        //商户私钥, 请把生成的私钥文件中字符串拷贝在此
        'merchant_private_key' => "MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDOCGNWwNjx9ephQRRB5mzwWAT0QAdva53y9s4OSZCbFTyO2BU//YpGC14FQCUHBzlOIffC8/jB9l7nIqSpfRvPRxUmDTwyG8ANcStFWtFWRTGjXJupjB43UfimUH/OPwJrKp2caleMLDFQjXz1ikAyfRx1ZVPxd/QzaBEae/hQygstIyKZVoMRWWXo2i4Z2G6oNEMda13b9LSMyA7wjxn2e2TJStKfBLrcKfwMu7nKEZp8baZKyDmyHs2At8RPDxIiGohkqcjDNuqnw5XJ0gntxzspuqlF/Xms/noCtX3R1tUWAgndJtPqLRO+Yb9UxdcEqEZ6TUYMvH/WM+KmJOZfAgMBAAECggEBAJ4D0uRbPUe9OkfimL2+Evj2GL6XSNyMZfRMk1Zj11MJo4tOcGXGd0EnQLG4M23DfZDN/m53nOZtpPWSHUWcHTMIqlCnv+4SWGY20F/9uiV3Jg3LXdtYCmiVJqWvgYXVz24Pnheze3eXAS9thFPw9zGBwMzMrOe5/wFaJBvyzkxueAL/RFY3Xk/Sg5IyfjC0o9LMdZ8I5OiDQ8VTY+ovhWaySRCvjN6H5Kl4axAfXYGooKIBjOl96qgXo9e01M0DwdFhSDeL//0xDMQWovsllEYrMGGDCJ0y+1DsjpXp8/aFjTxP1wGVXFUoyFe6EDGyDe984P6qopNIGPXjHVVqOQECgYEA8jPfbxfPQGMJVpQ+qEh3Zpkv+RRZyi9dVl2xxa3LgL0QcQoUfu/MG/WhDCXoUJ7wsXW3lbYu2a5uaz2XPrG1CroET7nMJQegFpOUF/lMcYcguECaSq9b/coKRu4tq/pyN0YDyVb0S+yh/t8k3PhEiCJ9imnoHFtPMtbmcqdRtt8CgYEA2cUJikYjUFCAdWpIrLLM3ghINxdc2DduaXZe7J9gc3zSqpfiaIkgC4Q3FiYfPtlPgF9wZneQSG1+a3bA46VycQiyEMC5h/Vhsj/BgNSwukG/bf1AsLsCMPDAhr0mEPwNJE3xWW2Hc2K+qbqKCA6zMWLMAOlJSqWFTHpUHl/AQIECgYB5PWotTDfcvTahdlffGVdbrncLMhq4UPliEEi68YKbEQk37JnR6Ou9WzmgwSEHqmhGDO03LhlJsj1nxU7+fSppEjCyUAlWx/hlFL7fOVYAxmmkkgIqPJnJ8ucuFnAaVKXz8UJX+QUVNIDq+nyTeFul4c4CCX29JCADDPwSjJsk9QKBgQDPgjsKALWLxXny6Hkh3yrqc/fkTyXQfll+syXW0jPFOG9B0YMT236mmrEnMOJbMBXanJbtfQcGjReG7Vz2T2QSo5eR8SOZk1Ap2yjXS1Sv1xDDjSxEe56l5fN/MOQCETuwmXjen0kPwUsvTqpS7TcBW0RLpgCJ2dmAO5zGaLU4gQKBgA7kTNXZJCdRjFEkwtTdY6/jZmWlcMuz7JEChrvs1aggB9BpAS81vUiNRwf76I4P46cf++p1mlFkjnyNYkcXsLTkTCIcKpIVkh5ysOxFiRxwZZwKo5vRwPTUTKeBnwY1S7aq6G44a9sNzf1KHxeXsJO1/Gh4IzcpyDPjGqtCvvTG",

        //异步通知地址
        'notify_url' => "http://www.myjys.cn/home/Notify/index",

        //同步跳转
        'return_url' => "http://www.myjys.cn/home/entry/index",

        //编码格式
        'charset' => "UTF-8",

        //签名方式
        'sign_type'=>"RSA",

        //支付宝网关
        'gatewayUrl' => "https://openapi.alipay.com/gateway.do",

        //支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
        'alipay_public_key' => "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDDI6d306Q8fIfCOaTXyiUeJHkrIvYISRcc73s3vF1ZT7XN8RNPwJxo8pWaJMmvyTn9N4HQ632qJBVHf8sxHi/fEsraprwCtzvzQETrNRwVxLO5jVmRGi60j8Ue1efIlzPXV9je9mkjzOmdssymZkh2QhUrCmZYI/FCEa3/cNMW0QIDAQAB",
];
