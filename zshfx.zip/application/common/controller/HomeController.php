<?php
namespace app\common\controller;
use think\Controller;

class HomeController extends Controller
{
    protected $title;
    protected $t_name;
    protected $t_content;
    public function __construct()
    {
        parent::__construct();
       $title=db('title')->find();
       $this->title=$title['t_title'];
       $this->t_name=$title['t_name'];
       $this->t_content=$title['t_content'];
    }
}