<?php

namespace app\common\model;

use think\Model;

class Team extends Model
{
    public function team($user_id){
        //根据id查询出所有的团队成员个人信息
        $A1=db('member')
            ->where('m_introducer',$user_id)
            ->order('m_last_login desc')
            ->paginate(15)
            ->each(function($item,$k){
            $item['m_last_login']=date('Y-m-d H:i:s',$item['m_last_login']);
                $time=strtotime(date('Y-m-d'.'00:00:00',time()));
                //今日消费
             $item['td_buy']=   db('money_log')->where('p_user_id',$item['m_id'])->where('p_time','>',$time)->where('p_state',2)->sum('p_money');
             $item['td_buy']=number_format($item['td_buy'],2);
             //今日收益
             $item['td_earning']=db('profit_log')->where('p_user_id',$item['m_id'])->where('p_time','>',$time)->where('p_state',2)->sum('p_money');
             $item['td_earning']=number_format($item['td_earning'],2);
             //总收益
             $item['all_earning']=db('profit_log')->where('p_user_id',$item['m_id'])->where('p_state',2)->sum('p_money');
                $item['all_earning']=number_format($item['all_earning'],2);
             //总消费
             $item['all_buy']= db('money_log')->where('p_user_id',$item['m_id'])->where('p_state',2)->sum('p_money');
                $item['all_buy']=number_format($item['all_buy'],2);
             //总复投次数
//             $item['buy_num']=db('money_log')->where('p_user_id',$item['m_id'])->count('p_money');
             $item['buy_num']=db('money_log')->where('p_user_id',$item['m_id'])->where('p_info','收益钱包支付')->where(['p_state'=>2])->sum('p_money');
             $item['buy_num']='¥'.number_format($item['buy_num'],2);
            return $item;
        });
       return $A1;

    }
}
