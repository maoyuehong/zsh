<?php

namespace app\common\model;

use think\Db;
use think\Loader;
use think\Model;

class Earnings extends Model
{
    protected $pk='w_id';
    protected $table='withdrawals_log';
    public function check($data){
        //充值是判断用户是否绑定银行卡
        $m_bank_card=db('member')->where('m_id',$data['w_user_id'])->field('m_bank_card,m_alipay')->find();
        if(empty($m_bank_card['m_bank_card']) && empty($m_bank_card['m_alipay'])){
            return ['status'=>0,'msg'=>'您还没有绑定银行卡或支付宝'];
        }
        $validate=Loader::validate('Earnings');
        if(!$validate->check($data)){
            return ['status'=>0,'msg'=>$validate->getError()];
        }
        Db::startTrans();
        $res=db('member')->field('m_profit')->find($data['w_user_id']);
        $ratio=db('recharge_ratio')->field('r_withdrawals,r_min_money,r_max_money')->find();
        if($ratio['r_min_money']>$data['w_money']){
            return ['status'=>0,'msg'=>'提现金额最低'.$ratio['r_min_money']];
        }else if($data['w_money']>$ratio['r_max_money']){
            return ['status'=>0,'msg'=>'提现金额最多'.$ratio['r_max_money']];
        }else if(($data['w_money']%100)!=0 || (round($data['w_money'])!=$data['w_money'])){
            return ['status'=>0,'msg'=>'提现金额格式：'.round($ratio['r_min_money']).','. ($ratio['r_min_money']+100) .'...'.($ratio['r_max_money']-100).','.round($ratio['r_max_money'])];
        }
        $shouxu=$data['w_money']*($ratio['r_withdrawals']/100);
        $money=$res['m_profit']-$data['w_money'];
        if($money<0){
            return ['status'=>0,'msg'=>'收益余额不足'];
        }
        $code=session('data');
        $nowtime = (time() - $code['nowtime']) / 60;
        if(empty($data['code'])){
            return ['status'=>0,'msg'=>'请填写验证码'];
        }
        if ($data['code'] != $code['code']) {
            return ['status' => 0, 'msg' => '验证码错误,请您重新获取...'];
        }
        if ($nowtime > 30) {//判断验证码是否超时
            return ['status' => 0, 'msg' => '验证码过期,请您重新获取...'];
        }
        $res1=db('member')->where('m_id',$data['w_user_id'])->update(['m_profit'=>$money]);
        //验证通过
        $data['w_time']=time();
        $data['w_id']=time().mt_rand(1000,9999).$data['w_user_id'];
        $data['w_info']="收益提现金额￥".($data['w_money']-$shouxu).",额外扣除￥".$shouxu."元手续费";
        $res2=$this->allowField(true)->save($data);
        if($res1&&$res2){
            Db::commit();
            $phone=db('title')->field('t_admin_phone')->find();
            if(!empty($phone['t_admin_phone'])){
                sendSMS($phone['t_admin_phone'],[],"SMS_107435080");
            }
            return ['status'=>200];
        }else{
            Db::rollback();
            return ['status'=>0,'msg'=>'提现失败'];
        }
    }
}
