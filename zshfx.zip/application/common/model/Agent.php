<?php
namespace app\common\model;
use think\Model;

class Agent extends Model
{
    //县级代理：直推10万（A下面有无数个B，所有B的总消费金额，不包含总收益钱包充值），至少有二区（2条下线B1和B2）业绩各达到120万，A享受团队业绩的1%
    public function agent($user_id)
    {   //查询代理等级
        $agent=db('member')->where('m_id',$user_id)->field('m_agent,m_sum_money,m_assets')->find();
        //代理级别获取金额比例以及县级代理满足的要求
        $ratio=db('agent_ratio')->find();
        if($agent['m_agent']==0){//没有级别
            //查询出所有一级代理的充值总金额
            $info=db('member')->where('m_introducer',$user_id)->sum('m_sum_money');
            if(!empty($info)&&$info>=$ratio['a_sum_money'])
            {
                //当前用户所有一级代理充值总金额已满足要求
                $num=0;
                //至少两条下线业绩各达120万
                //所有B级
                $B=db('member')->where('m_introducer',$user_id)->select();//所有B级代理
                foreach($B as $k1=>$v1)
                {   //当前B级用户总充值金额
                    $money=$v1['m_sum_money'];
                    //查找所有c级代理
                    $C=db('member')->where('m_introducer',$v1['m_id'])->select();
                    if(!empty($C)){
                        //有二级用户
                        foreach ($C as $k2=>$v2)
                        {
                            //当前分区下得所有二级用户
                            $money+=$v2['m_sum_money'];
                            //查找所有D级用户
                            $D=db('member')->where('m_introducer',$v2['m_id'])->select();
                            if(!empty($D)){
                                foreach ($D as $k3=>$v3)
                                {
                                    ////当前分区下得所有三级用户
                                    $money+=$v3['m_sum_money'];
                                }
                            }
                        }
                    }
                    if($money>=$ratio['a_money']){
                        $num++;//不管是哪一个B级用户,只要达到120000就成立
                    }
                }
                if($num>=2){
                    //表示有A成为县级代理。。。。。。。。。
                    //享受代理团队提成：查询此团队中有哪些代理，
                    $A123_money=$this->commonB($user_id,$ratio);
                    $money=($A123_money+$agent['m_sum_money'])*($ratio['a_a']/100);
                    $A_money=$agent['m_assets']+$money;
                    //修改状态为县级代理和获利的金额(到总金额)
                    db('member')->where('m_id',$user_id)->setField(['m_agent'=>1,'m_assets'=>$A_money]);
                    $data['p_id']=time().rand(1000,9999).$user_id;
                    $data['p_user_id']=$user_id;
                    $data['p_info']="升级为县级代理,奖励￥".$money.'存入总资产';
                    $data['p_money']=$money;
                    $data['p_state']=2;
                    $data['p_time']=time();
                    db('profit_log')->insert($data);
                }
            }
        }else if($agent['m_agent']==1){
            //当前用户为县级代理
            $info=db('member')->where('m_introducer',$user_id)->where('m_agent',1)->count();
            if(!empty($info)&&$info>=3){
                //当前用户成为市级代理
                $A123_money=$this->commonB($user_id,$ratio);
                $money=($A123_money+$agent['m_sum_money'])*($ratio['a_b']/100);
                $A_money=$agent['m_assets']+$money;
                //修改状态为市级代理和获利的金额(到总金额)
                db('member')->where('m_id',$user_id)->setField(['m_agent'=>2,'m_assets'=>$A_money]);
                $data['p_id']=time().rand(1000,9999).$user_id;
                $data['p_user_id']=$user_id;
                $data['p_info']="升级为市级代理,奖励￥".$money.'存入总资产';
                $data['p_money']=$money;
                $data['p_state']=2;
                $data['p_time']=time();
                db('profit_log')->insert($data);
            }
        }else if($agent['m_agent']==2){
            //当前用户为市级代理
            $info=db('member')->where('m_introducer',$user_id)->where('m_agent',2)->count();
            if(!empty($info)&&$info>=3){
                //当前用户成为省级代理
                $A123_money=$this->commonB($user_id,$ratio);
                $money=($A123_money+$agent['m_sum_money'])*($ratio['a_c']/100);
                $A_money=$agent['m_assets']+$money;
                //修改状态为省级代理和获利的金额(到总金额)
                db('member')->where('m_id',$user_id)->setField(['m_agent'=>3,'m_assets'=>$A_money]);
                $data['p_id']=time().rand(1000,9999).$user_id;
                $data['p_user_id']=$user_id;
                $data['p_info']="升级为省级代理,奖励￥".$money.'存入总资产';
                $data['p_money']=$money;
                $data['p_state']=2;
                $data['p_time']=time();
                db('profit_log')->insert($data);
            }
        }else if($agent['m_agent']==3){
            //当前用户为省级代理
            $info=db('member')->where('m_introducer',$user_id)->where('m_agent',3)->count();
            if(!empty($info)&&$info>=3){
                //当前用户成为股东
                $A123_money=$this->commonB($user_id,$ratio);
                $money=($A123_money+$agent['m_sum_money'])*($ratio['a_d']/100);
                $A_money=$agent['m_assets']+$money;
                //修改状态为股东和获利的金额(到总金额)
                db('member')->where('m_id',$user_id)->setField(['m_agent'=>4,'m_assets'=>$A_money]);
                $data['p_id']=time().rand(1000,9999).$user_id;
                $data['p_user_id']=$user_id;
                $data['p_info']="升级为股东,奖励￥".$money.'存入总资产';
                $data['p_money']=$money;
                $data['p_state']=2;
                $data['p_time']=time();
                db('profit_log')->insert($data);
            }
        }

    }

    /************************************************************************************************/
    public function commonB($A_id,$ratio){
        $all_money='';
        $money='';
        $A23_money='';
        //根据用户id找出所有一级推荐人（当前用户所有下一级）
        $A1=db('member')->where('m_introducer',$A_id)->select();

        foreach($A1 as $k=>$v){
            //算出所有A1代理的充值总金额
            $all_money+=$v['m_sum_money'];
            if($v['m_agent']==1){
                //有县级代理
                $money1=$v['m_sum_money'];//当前县级代理的充值总金额
                $A23_money+=$A23_money_1=$this->commonC($v['m_id'],$ratio);

                $money+=($money1+$A23_money_1)*($ratio['a_a']/100);//这是一级县级代理吃掉的金额

            }else if($v['m_agent']==2){
                $money1=$v['m_sum_money'];
                $A23_money+=$A23_money_2=$this->commonC($v['m_id'],$ratio);

                $money+=($money1+$A23_money_2)*($ratio['a_b']/100);
            }else if($v['m_agent']==3){
                $money1=$v['m_sum_money'];
                $A23_money+=$A23_money_3=$this->commonC($v['m_id'],$ratio);
                $money+=($money1+$A23_money_3)*($ratio['a_c']/100);
            }else if($v['m_agent']==4){
                $money1=$v['m_sum_money'];
                $A23_money+=$A23_money_4=$this->commonC($v['m_id'],$ratio);
                $money+=($money1+$A23_money_4)*($ratio['a_d']/100);
            }else if($v['m_agent']==0){
                $A23_money+=$this->commonC($v['m_id'],$ratio);
            }
        }
//        halt($A23_money);
        $money=$all_money-$money;//所有一级代理拿走的金额
        return $money+$A23_money;//所有一二三级代理剩余的金额
    }
    public function commonC($B_id,$ratio){
        $all_money='';
        $money='';
        $A3_money='';
        $A2=db('member')->where('m_introducer',$B_id)->select();
//        halt($A2);
        foreach($A2 as $k1=>$v1){
            //算出所有A2代理的充值总金额
            $all_money+=$v1['m_sum_money'];
            if($v1['m_agent']==1){
                //当前用户为县级代理
                $money1=$v1['m_sum_money'];//当前县级代理的充值总金额
                $A3_money+=$A3_money_1=$this->commonD($v1['m_id'],$ratio);//返回所有三级县级用户剩余金额
                $money+=($money1+$A3_money_1)*($ratio['a_a']/100);//这是二级县级代理拿走的金额
            }else if($v1['m_agent']==2){
                $money1=$v1['m_sum_money'];
                $A3_money+=$A3_money_2=$this->commonD($v1['m_id'],$ratio);
                $money+=($money1+$A3_money_2)*($ratio['a_b']/100);
            }else if($v1['m_agent']==3){
                $money1=$v1['m_sum_money'];
                $A3_money+=$A3_money_3=$this->commonD($v1['m_id'],$ratio);
                $money+=($money1+$A3_money_3)*($ratio['a_c']/100);
            }else if($v1['m_agent']==4){
                $money1=$v1['m_sum_money'];
                $A3_money+=$A3_money_4=$this->commonD($v1['m_id'],$ratio);
                $money+=($money1+$A3_money_4)*($ratio['a_d']/100);
            }else if($v1['m_agent']==0){
                $A3_money+=$this->commonD($v1['m_id'],$ratio);
            }

        }
//        halt($money);
        $money=$all_money-$money;//所有二级用户拿走的金额

        return $money+$A3_money;//返回二三级用户剩余的金额
    }

    public function commonD($C_id,$ratio){
        $all_money='';
        $money='';
        $A3=db('member')->where('m_introducer',$C_id)->select();
        foreach ($A3 as $k2=>$v2){
            //算出所有A3代理的充值总金额
            $all_money+=$v2['m_sum_money'];
            if($v2['m_agent']==1){
                //当前用A3为县级代理
                $money1=$v2['m_sum_money'];//当前县级代理的充值总金额
                $money+=$money1*($ratio['a_a']/100);//这是三级县级代理拿走的金额
            }else if($v2['m_agent']==2){
                //当前用户A3为市级代理
                $money1=$v2['m_sum_money'];
                $money+=$money1*($ratio['a_b']/100);
            }else if($v2['m_agent']==3){
                //当前用户A3为市级代理
                $money1=$v2['m_sum_money'];
                $money+=$money1*($ratio['a_c']/100);
            }else if($v2['m_agent']==4){
                //当前用户A3为市级代理
                $money1=$v2['m_sum_money'];
                $money+=$money1*($ratio['a_d']/100);
            }
        }
        $money=$all_money-$money;//所有A3代理-当前级别县级代理拿走的金额=A3用户剩余的金额
        return $money;//返回三级代理剩余的金额
    }

}