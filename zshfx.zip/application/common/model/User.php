<?php

namespace app\common\model;

use think\Loader;
use think\Model;

class User extends Model
{
    protected $pk='m_id';
    protected $table='member';
    protected $field=true;
    //公共方法
    private function common($data)
    {
        // 调用当前模型对应的this验证器类进行数据验证
        $result = Loader::validate('User')->check($data);
        if (false === $result) {
            // 验证失败 输出错误信息
            return ['status' => 0, 'msg' => Loader::validate('User')->getError()];
        } else {
            $code = session('data');
            //上次发送验证码到现在的时间
            $nowtime = (time() - $code['nowtime']) / 60;
            //判断发送验证码的手机是否与填写的手机一致
            if ($code['tel'] == $data['username']) {
                if ($data['captcha'] != $code['code']) {
                    return ['status' => 0, 'msg' => '验证码错误,请您重新获取...'];
                }
                if ($nowtime > 30) {//判断验证码是否超时
                    return ['status' => 0, 'msg' => '验证码过期,请您重新获取...'];
                }
                return ['status'=>200];
            } else {
                return ['status' => 0, 'msg' => '验证码错误!!!!请您重新获取'];
            }
        }
    }
    //注册
    public function pass($data)
    {
        //推荐人不能为空
           if(empty($data['user']))
           {
             return ['status'=>0,'msg'=>'请填写推荐人'];
            }else{
               $introducer = db('member')->where('m_user', $data['user'])->find();
               if(!$introducer){
                   return ['status'=>0,'msg'=>'该推荐人不存在'];
               }
           }
            $m_user=db('member')->where('m_user',$data['m_user'])->count();
            if($m_user>=1){
                return ['status'=>0,'msg'=>'你输入的用户名已经存在'];
            }
            $jj= $this->common($data);
            if($jj['status']==0){
                return $jj;
            }else{
                if(empty($data['m_name'])){
                    return['status'=>0,'msg'=>'请填写用户名'];
                }
                if(empty($data['m_id_card'])){
                    return['status'=>0,'msg'=>'请填写身份证号码'];
                }
                 $shuju['m_mobile']=$data['username'];//用户手机
                 $shuju['m_password']=md5($data['password']);//用户密码
                //根据推荐人号码查询到推荐人id
                if(!empty($data['user'])){
                    //2，通过推荐人号码查找到推荐人id
                    $introducer=$this->where('m_user',$data['user'])->field('m_id')->find();
                }else{
                    $introducer['m_id'] = 0;
                }


                $shuju['m_introducer']=$introducer['m_id'];//推荐人id
                $shuju['m_name']=$data['m_name'];//用户名真实姓名
                $shuju['m_id_card']=$data['m_id_card'];
                $shuju['m_time']=time();
                $shuju['m_user']=$data['m_user'];
                $res=$this->allowField(true)->save($shuju);
                if($res){
                    return ['status'=>200,'msg'=>'注册成功'];
                }else{
                    return ['status'=>0,'msg'=>'注册失败'];
                }


        }
}
    //修改密码
    public function updPwd($data){
        $m_user=$this->where('m_user',$data['m_user'])->field('m_id')->find();
        if(!$m_user){
            return ['status'=>0,'msg'=>'该用户不存在'];
        }

        $res= $this->common($data);
        if(!$res['status']){
            return $res;
        }else{
            $shuju['m_password']=md5($data['password']);
            $this->where('m_user',$data['m_user'])->update($shuju);
            return['status'=>200];
        }
    }
    //登陆验证
    public function login($data)
    {
//        halt($data);
        $validate = Loader::validate('login');
        if(!$validate->check($data)){
//            dump($validate->getError());
            return ['status'=>0,'msg'=>$validate->getError()];
        }else{
            $user=$this->where('m_user',$data['m_user'])->find();//判断用户账号是否输入正确
            $pwd=$this->where('m_user',$data['m_user'])->field('m_password')->find();//通过用户查找密码
//            halt($pwd['m_password']);
            if(!$user){
                return ['status'=>0,'msg'=>'用户名输入错误'];
            }else if($pwd['m_password']!=md5($data['m_password'])){
                return ['status'=>0,'msg'=>'用户名或密码错误'];
            }else{
               /* Cookie('key',$user['m_id']);
                Cookie('user',$user['m_name']);*/
               $this->where('m_id',$user['m_id'])->update(['m_last_login'=>time()]);
                return ['status'=>200,'id'=>$user['m_id'],'tel'=>$user['m_mobile'],'m_user'=>$data['m_user']];
            }
        }
    }
    //用户信息编辑
    public function info($data){
        $result = $this->validate(
            [
                'm_name' => 'require|max:25',
                'm_id_card'=>'require',
                'm_birthday' => 'require',
                'm_address' =>'require'

            ],
            [
                'm_name.require' => '名称必须',
                'name.max' => '名称最多不能超过25个字符',
                'm_birthday'=>'请选择出生日期',
                'm_address'=>'请选择所在地址',
                'm_id_card'=>'请填写身份证号码'
            ]
        )->save($data,['m_id'=>$data['id']]);
        if(false === $result){
            // 验证失败 输出错误信息
            return ['status'=>0,'msg'=>$this->getError()];
        }else{
            return ['status'=>200,'msg'=>'更新成功'];
        }
    }
    //银行卡绑定
    public function Bank($data){
        // 调用Member验证器类进行数据验证
            $result = $this->save($data,$this->pk);
        if(false === $result){
            // 验证失败 输出错误信息
            return ['status'=>0,'msg'=>'更新失败'];
        }else{
            return ['status'=>200];
        }
    }

}

