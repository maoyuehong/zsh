<?php
 function commonB($A_id,$ratio){
   //根据用户id超找出所一级推荐人
     db('member')->where('m_introducer',$A_id)->select();
 }
 function commonC($B_id,$ratio){


}

 function commonD($C_id,$ratio){

}