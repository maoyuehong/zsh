<?php

namespace app\common\model;

use think\Db;
use think\Loader;
use think\Model;

class Recharge extends Model
{
    protected $pk='p_id';
    protected $table='money_log';
    public function rech($data)
    {
        $validate = Loader::validate('Recharge');
        //        halt($validate);
        if (!$validate->check($data))
        {
            return ['status' => 0, 'msg' => $validate->getError()];
        }
        $ratio2=db('recharge_ratio')->find();
        if((($data['p_money']%10)!=0) || (round($data['p_money'])!=$data['p_money'])){
            return ['status'=>0,'msg'=>'充值金额格式：'.round($ratio2['r_min_recharge']).','. ($ratio2['r_min_recharge']+10) .'...'.($ratio2['r_max_recharge']-10).','.round($ratio2['r_max_recharge'])];
        }
        if ($data['p_info'] == '收益钱包支付')
        {
            Db::startTrans();
            //当用户A充值时用户收益
            //1,判断用户的收益余额是否充足
            $info=db('member')->where('m_id',$data['p_user_id'])->field('m_profit,m_assets,m_sum_money,m_introducer,m_mobile')->find();


            if($info['m_profit']<$data['p_money'])
            {
                //用户余额不足
                return ['status'=>0,'msg'=>'你的余额不足'];
            }
            $ratio1=db('recharge_ratio')->find();
            //2,更新用户现有收益余额和用户的总资产
            $profit=$info['m_profit']-$data['p_money'];
            //用户现有总资产=总资产余额+充值金额+充值金额/2
            $assets=$info['m_assets']+$data['p_money']*($ratio1['r_money']/100);
            $res=db('member')
                ->where('m_id',$data['p_user_id'])
                ->update(['m_profit'=>$profit,'m_assets'=>$assets]);
            //3,用户充值的金额累加到用户的总充值金额
            /*
             * 总充值金额只针对现金充值，则不能累加到总充值金额
             * */
            //更新用户A的充值记录信息
            $data['p_time']=time();
            $data['p_id']=time().mt_rand(1000,9999).$data['p_user_id'];
            $data['p_state']=2;
            $res0=$this->allowField(true)->save($data);

            if($res&&$res0)
            {
                //根据A的推荐人id查找出一级推荐人A1的相关信息(找到用户上一级)
                $A1=db('member')->where('m_id',$info['m_introducer'])->find();
                if($A1)
                {
                    //有一级推荐人
                    //获取用户A的一级推荐人A1充值金额达到多少时，可以获取A的充值金额
                    $recharge=db('distribution_money')->find();
                    //获取收益比例表信息
                    $ratio=db('distribution_ratio')->find();
                    //根据一级推荐人查找“一级推荐人下面”的所有一级推荐人总充值金额
                    $sum_money=db('member')->where('m_introducer',$A1['m_id'])->sum('m_sum_money');
                    //判断A1的总充值金额是否达到收益要求
                    if($sum_money>=$recharge['d_a'])
                    {
                        //一级推荐人A1达到要求
                        //计算一级推荐人该获取的收益
                        $money=$data['p_money']*($ratio['d_a']/100);
                        if(empty($money)){
                            $res1=true;
                            $res2=true;
                        }else{
                            //更新一级推荐人A1的总资产
                            $res1=db('member')->where('m_id',$info['m_introducer'])->setInc('m_assets',$money);
                            //A1的收益信息添加进收益表
                            $res2=db('profit_log')->insert([
                                'p_id'=>time().mt_rand(1000,9999).$A1['m_id'],
                                'p_user_id'=>$A1['m_id'],//一级推荐人id0
                                'p_info'=>"被推荐人***".substr($info['m_mobile'],-4)."充值,推荐人奖励￥".round($money,2)."存入总资产",
                                'p_money'=>$money,//收益金额
                                'p_state'=>2,
                                'p_time'=>time(),
                            ]);
                        }
                        if(!$res1 || !$res2){
                            Db::rollback();
                            return ['status'=>0,'msg'=>'充值失败'];
                        }
                    }
                    //根据一级推荐人A1找出二级推荐人A2
                    $A2=db('member')->where('m_id',$A1['m_introducer'])->find();
                    if($A2){
                        //有二级推荐人
                        //根据二级推荐人查找“二级推荐人下面”的所有一级推荐人总充值金额
                        $sum_money=db('member')->where('m_introducer',$A2['m_id'])->sum('m_sum_money');
                        if($sum_money>=$recharge['d_b']) {
                            //一级推荐人A1达到要求
                            //获取收益比例表信息
                            /*$ratio=db('distribution_ratio')->find();*/
                            //计算二级推荐人该获取的收益
                            $money = $data['p_money'] * ($ratio['d_b'] / 100);
                            if (empty($money)) {
                                $res3 = true;
                                $res4 = true;
                            } else {
                                //更新二级推荐人A2的总资产
                                $res3 = db('member')->where('m_id', $A1['m_introducer'])->setInc('m_assets', $money);
                                //A2的收益信息添加进收益表
                                $res4 = db('profit_log')->insert([
                                    'p_id'      => time() . mt_rand(1000, 9999) . $A2['m_id'],
                                    'p_user_id' => $A2['m_id'],//一级推荐人id
                                    'p_info'    => "被推荐人***" . substr($A1['m_mobile'], -4) . "充值,推荐人奖励￥" . round($money, 2) . "存入总资产",
                                    'p_money'   => $money,//收益金额
                                    'p_state'   => 2,
                                    'p_time'    => time(),
                                ]);
                            }
                            if(!$res3 || !$res4){
                                Db::rollback();
                                return ['status'=>0,'msg'=>'充值失败'];
                            }
                        }

                        //根据二级推荐人A2找三级推荐人A3
                        $A3=db('member')->where('m_id',$A2['m_introducer'])->find();
                        if($A3){
                            //有三级推荐人
                            //根据二级推荐人查找“二级推荐人下面”的所有一级推荐人总充值金额
                            $sum_money=db('member')->where('m_introducer',$A3['m_id'])->sum('m_sum_money');
                            if($sum_money>=$recharge['d_c']) {
                                //一级推荐人A1达到要求
                                //获取收益比例表信息
                                /*$ratio=db('distribution_ratio')->find();*/
                                //计算二级推荐人该获取的收益
                                $money = $data['p_money'] * ($ratio['d_c'] / 100);
                                if (empty($money)) {
                                    $res5 = true;
                                    $res6 = true;
                                } else {
                                    //更新三级推荐人A3的总资产
                                    $res5 = db('member')->where('m_id', $A2['m_introducer'])->setInc('m_assets', $money);
                                    //A2的收益信息添加进收益表
                                    $res6 = db('profit_log')->insert([
                                        'p_id'      => time() . mt_rand(1000, 9999) . $A3['m_id'],
                                        'p_user_id' => $A3['m_id'],//一级推荐人id
                                        'p_info'    => "被推荐人***" . substr($A2['m_mobile'], -4) . "充值,推荐人奖励￥" . round($money, 2) . "存入总资产",
                                        'p_money'   => $money,//收益金额
                                        'p_state'   => 2,
                                        'p_time'    => time(),
                                    ]);
                                }
                                if(!$res5 || !$res6){
                                    Db::rollback();
                                    return ['status'=>0,'msg'=>'充值失败'];
                                }else{
                                    Db::commit();
                                    return ['status'=>200];
                                }
                            }else{
                                Db::commit();
                                return ['status'=>200];
                            }

                        }else{
                            //没有三级推荐人
                            //提交
                            Db::commit();
                            return ['status'=>200];
                        }
                    }else{
                        //没有一级推荐人
                        //提交
                        Db::commit();
                        return ['status'=>200];
                    }

                }else{
                    //没有一级推荐人
                    //提交
                    Db::commit();
                    return ['status'=>200];
                }

            }else{
                //回退
                Db::rollback();
                return ['status'=>0,'msg'=>'充值失败'];
            }
            //4,查找用户一级推荐人B
            //5,更新用户B的总收益
            //6,更新用户B的收益记录
            //7，查找用户二级推荐人C
            //8，更新用户C的总收益
            //9，更新用户C的收益记录
        }else if($data['p_info']=='支付宝支付'){
            $data['p_id']=time().mt_rand(1000,9999).$data['p_user_id'];
            $data['p_state']=1;
            $data['p_time']=time();
            $res=$this->allowField(true)->save($data);
            if($res){
                Db::commit();
                return ['status'=>300,'id'=>$data['p_id'],'money'=>$data['p_money']];
            }else{
                Db::rollback();
                return ['status'=>0,'msg'=>'充值失败'];
            }

        }else if($data['p_info']=='微信支付'){
            return ['status'=>0,'msg'=>'暂未开通此服务'];
        }
    }
}