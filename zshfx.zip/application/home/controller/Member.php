<?php
namespace app\home\controller;

use app\common\controller\HomeController;
use app\common\model\User;
use think\captcha\Captcha;
use think\Controller;
class Member extends HomeController
{
   /* //首页面
    public function index(){
        return $this->fetch();
    }*/
    //会员注册
    public function regist()
    {
        if(request()->isAjax())
        {   //接收注册表单数据
            $data=input('post.');
            $res=(new User())->pass($data);
            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
            return $this->fetch();
    }
    //获取验证码
    public function send(){
        if(request()->isAjax())
        {
            $tel=input('post.tel');
            $type=input('post.type');
            $m_user=input('post.m_user');
            if(!$tel||strlen($tel)<11)
            {
                echo json_encode(array('status'=>0,'msg'=>'手机号码输入错误'));die;
            }
            $mobile=db('member')->where('m_mobile',$tel)->count();
            if($type!=='upd'){
                if($mobile>=2){
                    echo json_encode(array('status'=>0,'msg'=>'手机号最多只能注册两个'));die;
                }
            }else{
                $user=db('member')->where('m_user',$m_user)->where('m_mobile',$tel)->find();
                if(empty($user)){
                    echo json_encode(array('status'=>0,'msg'=>'用户名或手机号码填写错误'));die;
                }
            }

            //短信验证码生成
            $data['code']=mt_rand(1000,9999);
            $data['nowtime']=time();
            $data['tel']=$tel;
            session('data',$data);
            $res=sendSMS($tel,array('code'=>$data['code'],"product"=>'dsd'));
            if($res->Code=='OK')
            {
                echo json_encode(array('status'=>200,'msg'=>'发送成功....'));
            }else{
                echo json_encode(array('status'=>0,'msg'=>'短信发送失败,请稍后再试....'));
            }

        }
    }
    //登陆页面
    public function login(){
        if(request()->isAjax())
        {

            $data=input('post.');
            $result=(new User())->login($data);
            echo json_encode($result);exit;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //忘记密码
    public function updPwd(){
        if(request()->isAjax()){
           $data=input('post.');
           $result=(new User())->updPwd($data);
            echo json_encode($result);exit;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
       return $this->fetch();
    }
    public function captcha(){
        $config=[
            'fontSize' => 13,
            // 验证码字体大小(px)
            'useCurve' => false,
            // 是否画混淆曲线
            'useNoise' => false,
            // 是否添加杂点
            'imageH'   => 0,
            // 验证码图片高度
            'imageW'   => 0,
            // 验证码图片宽度
            'length'   => 4,
            // 验证码位数
        ];
        $captcha = new Captcha($config);
        $captcha->codeSet = '0123456789';
        return $captcha->entry();
    }
    public function check_captcha(){
        $code=input('post.captcha');
        $captcha = new Captcha();
       echo json_encode($captcha->check($code));
    }
    //用户注册协议
    public function treaty(){
        if(request()->isAjax()){
            $res=db('title')->find();
            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
}
