<?php

namespace app\home\controller;

use app\common\controller\HomeController;
use think\Controller;

class Index extends HomeController
{
    public function Index(){
        if(request()->isAjax()){
            $data=input('post.type');

            if($data=='focus'){
                //获取幻灯片
                $res=db('focus_img')
                    ->order('f_order asc')
                    ->select();
                //头部公告
                $res['news']=db('news')
                    ->where('n_state',2)
                    ->field('n_title')
                    ->order('n_time desc')
                    ->select();
                //广告图片
                $res['img']=db('img')->find();
                foreach($res as $k=>$v){
                    if($k!=='news'){
                        if($k==='img'){
                            $res[$k]['i_img_1']='/upload/img/'.$v['i_img_1'];
                            $res[$k]['i_img_2']='/upload/img/'.$v['i_img_2'];
                            $res[$k]['i_img_3']='/upload/img/'.$v['i_img_3'];
                        }else{
                            $res[$k]['f_img']='/upload/focus_img/'.$v['f_img'];
                        }

                    }
                }
            }
            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    public function news(){
        if(request()->isAjax())
        {
            $type=input('post.type');
            if($type==1){
                $res=db('news')
                    ->order('n_time desc')
                    ->paginate(10)
                    ->each(function($item,$k){
                        $item['n_time']=date('Y-m-d H:i:s',$item['n_time']);
                        return $item;
                    });
            }else{
                $id=input('post.id');
                $res=db('news')
                    ->where('n_id',$id)
                    ->find();
                $res['n_time']=date('Y-m-d H:i:s',$res['n_time']);
            }
            echo json_encode($res);die;
        }
        if(input('get.type')==1){
            return $this->fetch();
        }else{
            return $this->fetch('newDetails');
        }

    }
}
