<?php

namespace app\home\controller;

use alipay\Query;
use think\Db;
use app\common\controller\NotifyHandler;

/**
 * 通知处理控制器
 *
 * 完善getOrder, 获取订单信息, 注意必须数组必须包含out_trade_no与total_amount
 * 完善checkOrderStatus, 返回订单状态, 按要求返回布尔值
 * 完善handle, 进行业务处理, 按要求返回布尔值
 *
 * 请求地址为index, NotifyHandler会自动调用以上三个方法
 */
class Notify extends NotifyHandler
{
    protected $params; // 订单信息
    protected $query_info;
    public function index()
    {
        $query = new Query();
        $info = $query->exec($_POST['trade_no']);

        if($info['trade_status']=="TRADE_SUCCESS" && $info['out_trade_no']==$_POST['out_trade_no']){
            $this->query_info = $info['trade_status'];
            parent::init();
        }else{
            echo "fail";

        }

    }

    /**
     * 获取订单信息, 必须包含订单号和订单金额
     *
     * @return string $params['out_trade_no'] 商户订单
     * @return float  $params['total_amount'] 订单金额
     */
    public function getOrder()
    {
        // 以下仅示例
        $out_trade_no = $_POST['out_trade_no'];
        $order = Db::name('money_log')->where('p_id', $out_trade_no)->find();
        if(!empty($order)){
            $params = [
                'total_amount' => $order['p_money'],
                'status'       => $order['p_state'],
                'out_trade_no' => $order['p_id'],
                'id'           =>$order['p_user_id']
            ];

            $this->params = $params;
            return true;
        }else{
            return false;
        }


    }

    /**
     * 检查订单状态
     *
     * @return Boolean true表示已经处理过 false表示未处理过
     */
    public function checkOrderStatus()
    {
        // 以下仅示例
        if($this->params['status'] == 1) {
            // 表示未处理
            return false;
        } else {
            return true;
        }
    }

    /**
     * 业务处理
     * @return Boolean true表示业务处理成功 false表示处理失败
     */
    public function handle()
    {
        $user_id=$this->params['id'];
        $money11=$this->params['total_amount'];
        $order_id=$this->params['out_trade_no'];
        Db::startTrans();
        //当用户A充值时用户收益
        //1,判断用户的收益余额是否充足
        $info=db('member')->where('m_id',$user_id)->field('m_profit,m_assets,m_sum_money,m_introducer,m_mobile')->find();
        /* if($info['m_profit']<$money)
         {
             //用户余额不足
             return ['status'=>0,'msg'=>'你的余额不足'];
         }*/
        $ratio1=db('recharge_ratio')->find();
        //2,更新用户现有收益余额和用户的总资产
        /* $profit=$info['m_profit']-$money;*/
        //用户现有总资产=总资产余额+充值金额+充值金额/2
        $shuju['m_assets']=$info['m_assets']+$money11*($ratio1['r_money']/100);
        $shuju['m_sum_money']=($info['m_sum_money']+$money11);
        $res=db('member')
            ->where('m_id',$user_id)
            ->update(['m_assets'=>$shuju['m_assets'],'m_sum_money'=>$shuju['m_sum_money']]);
        //3,用户充值的金额累加到用户的总充值金额
        /*
         * 总充值金额只针对现金充值，则不能累加到总充值金额
         * */
        //更新用户A的充值记录信息
        $data['p_time']=time();
        $data['p_state']=2;
        $res0=db('money_log')->where('p_id',$order_id)->update(['p_time'=>$data['p_time'],'p_state'=>$data['p_state']]);
        if($res&&$res0)
        {
            //根据A的推荐人id查找出一级推荐人A1的相关信息(找到用户上一级)
            $A1=db('member')->where('m_id',$info['m_introducer'])->find();
            if($A1)
            {
                //有一级推荐人
                //获取用户A的一级推荐人A1充值金额达到多少时，可以获取A的充值金额
                $recharge=db('distribution_money')->find();
                //根据一级推荐人查找“一级推荐人下面”的所有一级推荐人总充值金额
                $sum_money=db('member')->where('m_introducer',$A1['m_id'])->sum('m_sum_money');
                //获取收益比例表信息
                $ratio=db('distribution_ratio')->find();
                //判断A1的总充值金额是否达到收益要求
                if($sum_money>=$recharge['d_a'])
                {
                    //一级推荐人A1达到要求
                    //计算一级推荐人该获取的收益
                    $money=$money11*($ratio['d_a']/100);
                    if(empty($money)){
                        $res1=true;
                        $res2=true;
                    }else{
                        //更新一级推荐人A1的总资产
                        $res1=db('member')->where('m_id',$info['m_introducer'])->setInc('m_assets',$money);
                        //A1的收益信息添加进收益表
                        $res2=db('profit_log')->insert([
                            'p_id'=>time().mt_rand(1000,9999).$A1['m_id'],
                            'p_user_id'=>$A1['m_id'],//一级推荐人id0
                            'p_info'=>"被推荐人***".substr($info['m_mobile'],-4)."充值,推荐人奖励￥".round($money,2)."存入总资产",
                            'p_money'=>$money,//收益金额
                            'p_state'=>2,
                            'p_time'=>time(),
                        ]);
                    }
                    if(!$res1 || !$res2){
                        Db::rollback();
                        return false;
                    }
                }
                //根据一级推荐人A1找出二级推荐人A2
                $A2=db('member')->where('m_id',$A1['m_introducer'])->find();
                if($A2){
                    //有二级推荐人
                    //根据二级推荐人查找“二级推荐人下面”的所有一级推荐人总充值金额
                    $sum_money=db('member')->where('m_introducer',$A2['m_id'])->sum('m_sum_money');
                    if($sum_money>=$recharge['d_b']) {
                        //一级推荐人A1达到要求
                        //获取收益比例表信息
                        /*$ratio=db('distribution_ratio')->find();*/
                        //计算二级推荐人该获取的收益
                        $money = $money11 * ($ratio['d_b'] / 100);
                        if (empty($money)) {
                            $res3 = true;
                            $res4 = true;
                        } else {
                            //更新二级推荐人A2的总资产
                            $res3 = db('member')->where('m_id', $A1['m_introducer'])->setInc('m_assets', $money);
                            //A2的收益信息添加进收益表
                            $res4 = db('profit_log')->insert([
                                'p_id'      => time() . mt_rand(1000, 9999) . $A2['m_id'],
                                'p_user_id' => $A2['m_id'],//一级推荐人id
                                'p_info'    => "被推荐人***" . substr($A1['m_mobile'], -4) . "充值,推荐人奖励￥" . round($money, 2) . "存入总资产",
                                'p_money'   => $money,//收益金额
                                'p_state'   => 2,
                                'p_time'    => time(),
                            ]);
                        }
                        if(!$res3 || !$res4){
                            Db::rollback();
                            return false;
                        }
                    }

                    //根据二级推荐人A2找三级推荐人A3
                    $A3=db('member')->where('m_id',$A2['m_introducer'])->find();
                    if($A3){
                        //有三级推荐人
                        //根据二级推荐人查找“二级推荐人下面”的所有一级推荐人总充值金额
                        $sum_money=db('member')->where('m_introducer',$A3['m_id'])->sum('m_sum_money');
                        if($sum_money>=$recharge['d_c']) {
                            //一级推荐人A1达到要求
                            //获取收益比例表信息
                            /*$ratio=db('distribution_ratio')->find();*/
                            //计算二级推荐人该获取的收益
                            $money = $money11 * ($ratio['d_c'] / 100);
                            if (empty($money)) {
                                $res5 = true;
                                $res6 = true;
                            } else {
                                //更新三级推荐人A3的总资产
                                $res5 = db('member')->where('m_id', $A2['m_introducer'])->setInc('m_assets', $money);
                                //A2的收益信息添加进收益表
                                $res6 = db('profit_log')->insert([
                                    'p_id'      => time() . mt_rand(1000, 9999) . $A3['m_id'],
                                    'p_user_id' => $A3['m_id'],//一级推荐人id
                                    'p_info'    => "被推荐人***" . substr($A2['m_mobile'], -4) . "充值,推荐人奖励￥" . round($money, 2) . "存入总资产",
                                    'p_money'   => $money,//收益金额
                                    'p_state'   => 2,
                                    'p_time'    => time(),
                                ]);
                            }
                            if(!$res5 || !$res6){
                                Db::rollback();
                                return false;
                            }else{
                                Db::commit();
                                return true;
                            }
                        }else{
                            Db::commit();
                            return true;
                        }

                    }else{
                        //没有三级推荐人
                        //提交
                        Db::commit();
                        return true;
                    }
                }else{
                    //没有一级推荐人
                    //提交
                    Db::commit();
                    return true;
                }

            }else{
                //没有一级推荐人
                //提交
                Db::commit();
                return true;
            }

        }else{
            //回退
            Db::rollback();
            return false;
        }
        // 以下仅示例
        //$result = Db::name('money_log')->where('p_id', $this->params['out_trade_no'])->update(['p_state'=>2]);

        /*if($result) {
            return true;
        } else {
            return false;
        }*/
    }
}