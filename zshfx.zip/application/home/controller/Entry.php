<?php

namespace app\home\controller;
use alipay\Wappay;
use app\common\controller\HomeController;
use app\common\model\Earnings;
use app\common\model\Recharge;
use app\common\model\Team;
use app\common\model\User;
use think\Controller;

class Entry extends HomeController
{
    public function dingshiqi(){
        earnings();
    }
    //代理
    public function agent(){
        agent();
    }
    //首页展示
    public function index()
    {
        if (request()->isAjax()){
            //获取基本买入（全部买入次数）数据
            $user_id=input('post.id');
            //获取今日零时零分
            $time=strtotime(date('Y-m-d'.'00:00:00',time()));
            //昨日零时零分
            $ytd_time=$time-24*3600;
            //收益余额和总资产余额
            $res2=db('member')
                    ->where('m_id',$user_id)
                    ->field('m_profit,m_assets')
                    ->find();
            //今日收益
            $res2['td_earnings']=db('profit_log')
                    ->where('p_time','>',$time)
                    ->where('p_user_id',$user_id)
                    ->sum('p_money');
            //昨日收益
            $res2['ytd_earnings']=db('profit_log')
                ->where('p_time','<',$time)
                ->where('p_time','>',$ytd_time)
                ->where('p_user_id',$user_id)
                ->sum('p_money');
            //总收益
            $res2['earnings']=db('profit_log')
                ->where('p_user_id',$user_id)
                ->sum('p_money');
            //我的团队
            $res1['team']=db('member')
                ->where('m_introducer',$user_id)
                ->count();
            //基本买入
            $res1['num']=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',2)
                    ->count('p_money');
            //提现总量
            $res1['w_money']=db('withdrawals_log')
                ->where('w_user_id',$user_id)
                ->where('w_state',2)
                ->count('w_money');
            //今日买入
            $res1['p_money']=db('money_log')
                ->where('p_user_id',$user_id)
                ->where('p_time','>',$time)
                ->where('p_state',2)
                ->count('p_money');
            //昨日买入
            $res1['ytd_p_money']=db('money_log')
                ->where('p_user_id',$user_id)
                ->where('p_time','<',$time)
                ->where('p_time','>',$ytd_time)
                ->where('p_state',2)
                ->count('p_money');
            foreach ($res2 as $k=>$v){
                $res2[$k]=round($v,2);
//                $res2[$k]=  $res2[$k]>=10000 ? $v/10000 .'万' : number_format($v,2);
            }
//            halt($res2);
            $rest=array_merge($res1,$res2);
            echo json_encode($rest);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
      return  $this->fetch();
    }
    //用户信息界面
    public function myprofile()
    {
        if(request()->isAjax())
        {
            $data=input('post.');
            $user_id=$data['id'];
            if($data['type']=='mobile'){
                $res=db('member')->where('m_id',$user_id)->field('m_mobile,m_name,m_birthday,m_address,m_user,m_id_card')->find();
                echo json_encode($res);die;
            }


        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //用户设置
    public function info(){
        $data=input('post.');
        $result=(new User())->info($data);
        echo json_encode($result);
    }
    //用户充值
    public function recharge(){
        if(request()->isAjax()){
            $data=input('post.');
            $data['p_user_id']=$data['id'];
            $res=(new Recharge())->rech($data);
          echo  json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //充值范围显示
    public function recharge1(){
        if(request()->isAjax()){
            $res=db('recharge_ratio')->find();
            $res['r_min_recharge']=$res['r_min_recharge']>=10000 ? $res['r_min_recharge']/10000 . '万' : round($res['r_min_recharge']).'元';
            $res['r_max_recharge']=$res['r_max_recharge']>=10000 ? $res['r_max_recharge']/10000 . '万' : round($res['r_max_recharge']).'元';
            echo json_encode($res);
        }
    }
    /*public function sessio(){
        $test=input('get.');
        session('name',$test);
      return  $this->fetch('rechange');
    }*/
    //充值记录页面
    public function rechange(){

        if(request()->isAjax()){
            $data=input('post.');
            $user_id=$data['id'];
            if($data['type']=='all'){
                //获取全部数据
                $res=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
                }
            if($data['type']=='unfinished'){
                //获取未完成的订单
                $res=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',1)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }
            if($data['type']=='over'){
                //获取未完成的订单
                $res=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',2)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }

                   echo json_encode($res);die;


        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //收益提现
    public function earnings(){
        if(request()->isAjax()){
            $data=input('post.');
            $user_id=$data['id'];
            if($data['type']=='get'){
                $res1=db('member')
                    ->where('m_id',$user_id)
                    ->field('m_profit')
                    ->find();//收益余额
                $res=db('recharge_ratio')->field('r_min_money,r_withdrawals,r_max_money')->find();
                $rest=array_merge($res1,$res);
                echo json_encode($rest);die;
            }
            if($data['type']=='post'){
                $data['w_user_id']=$user_id;
                $res=(new Earnings())->check($data);
                echo json_encode($res);die;
            }
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
       return $this->fetch();
    }
    //收益明细

    //2,提现记录
    public function Income(){
        if(request()->isAjax()){
            $type=input('post.type');
            $user_id=input('post.id');
            //收益记录
            if($type=='shouyi'){
                $res=db('profit_log')
                    ->where('p_user_id',$user_id)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }
            //提现记录
            if($type=='tixian'){
                $res=db('withdrawals_log')
                    ->where('w_user_id',$user_id)
                    ->order('w_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['w_time']=date('Y-m-d H:i:s',$item['w_time']);
                        return $item;
                    });


            }
            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
       return $this->fetch();
    }
    //买入明细
    public function buy(){
        if(request()->isAjax()){
            $data=input('post.type');
            $user_id=input('post.id');
            //获取今日零时零分
            $time=strtotime(date('Y-m-d'.'00:00:00',time()));
            //昨日零时零分
            $ytd_time=$time-24*3600;
            if($data==1){
                //基本买入（买入成功的）
                $res=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',2)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }else if($data==2){
                //今日买入
                $res=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',2)
                    ->where('p_time','>',$time)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }else{
                //昨日买入
                $res=db('money_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',2)
                    ->where('p_time','<',$time)
                    ->where('p_time','>',$ytd_time)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }
            /*foreach($res as $k=>$v){
                $res[$k]['p_time']=date('Y-m-d H:i:s',$v['p_time']);
            }*/
            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //今日收益
    public function all_earnings(){
        if(request()->isAjax()){
            $data=input('post.type');
            $user_id=input('post.id');
            //获取今日零时零分
            $time=strtotime(date('Y-m-d'.'00:00:00',time()));
            //昨日零时零分
            $ytd_time=$time-24*3600;
            if($data==1){
                //今日收益
                $res=db('profit_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_time','>',$time)
                    ->where('p_state',2)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });

            }else if($data==2){
                //昨日收益
                $res=db('profit_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_time','<',$time)
                    ->where('p_time','>',$ytd_time)
                    ->where('p_state',2)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }else{
                //总收益
                $res=db('profit_log')
                    ->where('p_user_id',$user_id)
                    ->where('p_state',2)
                    ->order('p_time desc')
                    ->paginate(7)
                    ->each(function($item,$k){
                        $item['p_time']=date('Y-m-d H:i:s',$item['p_time']);
                        return $item;
                    });
            }

            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //我的团队
    public function team(){
        if(request()->isAjax()){
            $user_id=input('post.id');
            $res=(new Team())->team($user_id);
            /*$res=db('member')
                ->where('m_introducer',$user_id)
                ->select();
            foreach ($res as $k=>$v){
                if($res[$k]['m_last_login']==0){
                    continue;
                }
                $res[$k]['m_last_login']=date('Y-m-d H:i:s',$v['m_last_login']);
            }*/
            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }

    //提现绑卡
    public function bank(){
        if(request()->isAjax()){
            $data=input('post.');
            $data['m_id']=$data['id'];
            if($data['type']==1){
                //获取数据
                $res=db('member')->where('m_id',$data['m_id'])->field('m_bank_nickname,m_bank_card,m_bank_address,m_bank_name,m_wx,m_alipay')->find();
            }else{
                $res=(new User())->Bank($data);
            }

            echo json_encode($res);die;
        }
        $this->assign(['title'=>$this->title,'t_name'=>$this->t_name,'t_content'=>$this->t_content]);
        return $this->fetch();
    }
    //邀请注册
    public function invite(){
        return $this->fetch('share');
    }
    //生成二维码
    public function share(){
        require '/../extend/phpqrcode/phpqrcode.php';
        $data = 'http://www.myjys.cn/home/member/regist';
//        $filename = 'memberqr_'.$user_id.'.png';  //  生成的文件名
        $errorCorrectionLevel = 'L';  // 纠错级别：L、M、Q、H
        $matrixPointSize = 7; // 点的大小：1到10
        \QRcode::png($data, false, $errorCorrectionLevel, $matrixPointSize, 1);
    }
    //支付宝充值
    public function alipay(){
        if(request()->isAjax()){
            $order_id=input('post.order_id');
            $state=db('money_log')->where('p_id',$order_id)->field('p_state status')->find();
            echo json_encode($state);die;
        }
        if ( strpos($_SERVER['HTTP_USER_AGENT'],'MicroMessenger') !== false ) {
            return $this->fetch('pay');
        }else{
            $data=input('get.');
            $wappay = new Wappay();
            $params['subject'] = "共襄合伙人充值￥".$data['money'];
            $params['out_trade_no'] = $data['id'];
            $params['total_amount'] = $data['money'];
            $wappay->pay($params);
        }

    }
    //删除订单
    public function del_order(){
        if(request()->isAjax()){
            $order_id=input('post.id');
            $res=db('money_log')->delete(['p_id'=>$order_id]);
            if($res){
                return ['status'=>200,'msg'=>'订单取消成功'];
            }
        }
    }
    //订单续付
    public function pay_order(){
        if(request()->isAjax()){
            $order_id=input('post.order_id');
            $res=db('money_log')->where('p_id',$order_id)->find();
            if($res){
                echo json_encode($res);
            }
        }
    }
    //提现发送验证码
    public function send(){
            $tel=input('post.tel');
            //短信验证码生成
            $data['code']=mt_rand(1000,9999);
            $data['nowtime']=time();
            $data['tel']=$tel;
            session('data',$data);
            $res=sendSMS($tel,array('code'=>$data['code'],"product"=>'dsd'));
            if($res->Code=='OK')
            {
                echo json_encode(array('status'=>200,'msg'=>'发送成功,请注意查收'));
            }else{
                echo json_encode(array('status'=>0,'msg'=>'短信发送失败,请稍后再试....'));
            }
         }
}