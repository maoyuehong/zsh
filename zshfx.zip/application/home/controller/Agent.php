<?php
namespace app\home\controller;
use think\Controller;

class Agent extends Controller
{
    public function proxy(){
        if(request()->isAjax()){
            $user_id=input('post.id');
            $index=input('post.index');
            //当前用户的个人信息
            $A=db('member')->where('m_id',$user_id)->find();
            $A1=db('member')->where('m_introducer',$user_id)->select();
            $team_money=0;
            $agent_1=0;
            $agent_2=0;
            $agent_3=0;
            $agent_4=0;
            if(!empty($A1)){
                if($index==1 ||$index==2 ||$index==3){
                    foreach($A1 as $k=>$v){
                        if($v['m_agent']==1){
                            $agent_1++;
                        }else if($v['m_agent']==2){
                            $agent_2++;
                        }else if($v['m_agent']==3){
                            $agent_3++;
                        }else if($v['m_agent']==4){
                            $agent_4++;
                        }
                        //获取一级代理总金额
                        $team_money+=$v['m_sum_money'];
                        $A2=db('member')->where('m_introducer',$v['m_id'])->select();
                        if(!empty($A2)){
                            if($index==1 ||$index==2 ){
                                foreach ($A2 as $k1=>$v1){
                                    if($v1['m_agent']==1){
                                        $agent_1++;
                                    }else if($v1['m_agent']==2){
                                        $agent_2++;
                                    }else if($v1['m_agent']==3){
                                        $agent_3++;
                                    }else if($v1['m_agent']==4){
                                        $agent_4++;
                                    }
                                    $team_money+=$v1['m_sum_money'];
                                    $A3=db('member')->where('m_introducer',$v1['m_id'])->select();
                                    if(!empty($A3)){
                                        if($index==1){
                                            foreach($A3 as $k2=>$v2){
                                                if($v2['m_agent']==1){
                                                    $agent_1++;
                                                }else if($v2['m_agent']==2){
                                                    $agent_2++;
                                                }else if($v2['m_agent']==3){
                                                    $agent_3++;
                                                }else if($v2['m_agent']==4){
                                                    $agent_4++;
                                                }
                                                $team_money+=$v2['m_sum_money'];
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            $A['agent_1']=$agent_1;
            $A['agent_2']=$agent_2;
            $A['agent_3']=$agent_3;
            $A['agent_4']=$agent_4;
            $A['team_money']=$team_money;
            echo json_encode($A);die;

        }
        return $this->fetch();
    }
    //分页数据
    public function index(){

        if(request()->isAjax()){
            $user_id=input('post.id');
            $res=db('member')
                ->where('m_introducer',$user_id)
                ->order('m_agent desc')
                ->paginate(10)
                ->each(function($item,$k){
                    $team_money=$item['m_sum_money'];
                    $index=input('post.index');
                    $a_a=db('member')->where('m_introducer',$item['m_id'])->select();
                    if(!empty($a_a)) {
                        if ($index == 1 || $index == 2 ) {
                            foreach ($a_a as $k1 => $v1) {
                                $team_money += $v1['m_sum_money'];
                                $a_b = db('member')->where('m_introducer', $v1['m_id'])->select();
                                if (!empty($a_b)) {
                                    if($index==1 ) {
                                        foreach ($a_b as $k2 => $v2) {
                                            $team_money += $v2['m_sum_money'];
                                        }
                                    }
                                }
                            }
                        }
                    }
                    $item['team_money']=number_format($team_money,2);
                    return $item;
                })
                ->toArray();
            ;
            echo json_encode($res);
        }
    }
}