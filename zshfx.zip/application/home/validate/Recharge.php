<?php
namespace app\home\validate;
use think\Validate;

class Recharge extends Validate{
    protected $min=111;
    protected $rule=[
        'p_money'=>'require|behavior:\app\home\behavior\recharge',
        'p_info'=>'require'
    ];
    protected $message=[
        'p_money.behavior'=>'充值金额不在指定的范围',
        'p_money.require'=>'请输入充值的金额',
//        'p_money.between'=>'充值金额在1元~4万之间',
        'p_info.require'=>'请选择支付方式'
    ];
}