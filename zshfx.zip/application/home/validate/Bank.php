<?php
namespace app\home\validate;
use think\Validate;

class Bank extends Validate{
    protected $rule=[
        'm_bank_nickname'=>"require",
        "m_bank_card"=>"require",
        "m_bank_address"=>"require",
        "m_bank_name"=>"require",
        "m_wx"=>"require",
        "m_alipay"=>"require",
    ];
    protected $message=[
        'm_bank_nickname.require'=>"请填写开户人名称",
        "m_bank_card.require"=>"请填写银行卡号",
        "m_bank_address.require"=>"请填开户行名称",
        "m_bank_name.require"=>"请填银行开户人名称",
        "m_wx.require"=>"请填写微信号",
        "m_alipay.require"=>"请填写支付宝账号",
    ];
}