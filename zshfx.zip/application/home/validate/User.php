<?php
namespace app\home\validate;
use think\Validate;
class User extends Validate
{
    protected $rule=[
       'm_user' =>'require|alphaNum|length:6,20',
      'username' =>'require|number|length:11',//手机号码
      //'user'     =>'behavior:\app\home\behavior\test',//推荐人号码，behavior是行为验证默认方法为run（）
      'captcha'  =>'require',//验证码
      'password' =>'require',//密码
      'password1'=>'require|confirm:password|length:6,20',

    ];
    protected $message=[
        'm_user.require'=>'请填写用户名',
        'm_user.alphaNum'=>'用户名只能由数字和字母组成',
        'm_user.length' =>'用户名必须在6到20位之间',
//        'm_user.behavior'=>'用户名已经存在',
      'username.require' =>'手机号码不能为空',
      'username.number'  =>'手机号码不正确',
      'username.length'  =>'手机号码不正确',
      //'user.behavior'    =>'该推荐人不存在,请重新填写',
      'captcha.require'  =>'验证码不能为空',
      'password.require' =>'密码不能为空',
      'password1.require'=>'请输入确认密码',
      'password1.confirm'=>'两次输入的密码不一致',
      'password1.length' =>'密码必须在6~20位之间'
    ];
}