<?php
namespace app\home\validate;
use think\Validate;

class Login extends Validate
{
    protected $rule=[

      'm_user'        =>'require',
      'm_password'      =>'require'

    ];
    protected $message=[
        'm_user.require'          =>'账号不能为空',
        'm_password.require'                =>'密码不能为空',
      /*  'captcha.require'           =>'请输入验证码',
        'captcha.captcha'           =>'验证码不正确',*/
    ];
}