<?php
namespace app\home\validate;
use think\Validate;

class Earnings extends Validate{
    protected $rule=[
      'w_money'=>'require',
    ];
    protected $message=[
      'w_money.require'=>'请输入您要提现的金额',
    ];
}