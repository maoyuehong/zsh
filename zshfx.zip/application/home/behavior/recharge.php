<?php
namespace app\home\behavior;
class recharge {
    public function run($data){
        //查找出用户充值金额范围
        $recharge=db('recharge_ratio')->field('r_min_recharge,r_max_recharge')->find();
        if($data['p_money']<$recharge['r_min_recharge']||$data['p_money']>$recharge['r_max_recharge'])
        {
            return false;
        }else{
            return true;
        }
    }
}