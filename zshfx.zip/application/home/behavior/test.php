<?php
namespace app\home\behavior;
class test
{
    //验证推荐人号码是否正确（行为验证默认方法为run）
  /*  public function run($data)
    {
        halt($data);
        $introducer = db('member')->where('m_user', $data['user'])->find();
//        halt($introducer);
        if (!$introducer) {
            return false;
        } else {
            return true;
        }
    }*/

    /*static public function run1($data)
    {
        //验证手机号码是否已经注册
        $mobile = db('member')->where('m_mobile', $data['username'])->find();
        if ($mobile) {
            return false;
        }else{
            return true;
        }
    }*/
    //用户账号是否唯一
    public function run($data){
        $m_user=db('member')->where('m_user',$data['m_user'])->count();
        if($m_user>=1){
            return false;
        }else{
            return true;
        }
    }
}