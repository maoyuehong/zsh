<?php

namespace app\Admin\controller;

use app\common\AdminController;
use think\Controller;

class Agent extends AdminController
{
    public function surface(){
        if(request()->isPost()) {
            $admin = db('agent_ratio');
            if (request()->isPost()) {
                //获取用户提交的额数据
                $info = input('post.');
                //dump($info);
                $shuju['a_a'] = $info['a'];
                $shuju['a_b'] = $info['b'];
                $shuju['a_c'] = $info['c'];
                $shuju['a_d'] = $info['d'];
                $shuju['a_sum_money'] = $info['a_sum_money'];
                $shuju['a_money'] = $info['money'];
                if ($admin->where(array('a_id' => 1))->update($shuju)) {
                    $this->error('修改成功');
                } else {
                    $this->error('您没有更新任何数据！');
                }


            }
        }
        $info=db('agent_ratio')->select();
        $this->assign('info',$info);
        return view('agent/surface');
    }
}
