<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件
function sendSMS($tel,$data,$num="SMS_104425012"){
    ini_set("display_errors", "on");
    //此处需要替换成自己的AK信息
    $accessKeyId = "LTAIEBGwTJtPrlaJ";//参考本文档步骤2
    $accessKeySecret = "zNAluM82TOgXz52BPWDJYOVuHySAxZ";//参考本文档步骤2
    //短信签名
    $sign='共襄';
    //短信模板编号
    $number=$num;
    //短信API产品名（短信产品名固定，无需修改）
    $product = "Dysmsapi";
    //短信API产品域名（接口地址固定，无需修改）
    $domain = "dysmsapi.aliyuncs.com";
    //暂时不支持多Region（目前仅支持cn-hangzhou请勿修改）
    $region = "cn-hangzhou";
    //初始化访问的acsCleint
//    require_once('/../extend/php/api_sdk/lib/Core/Profile/DefaultProfile.php');
    require_once '/../extend/php/api_sdk/vendor/autoload.php';
    // 加载区域结点配置
    \Aliyun\Core\Config::load();
    $profile = \Aliyun\Core\Profile\DefaultProfile::getProfile($region, $accessKeyId, $accessKeySecret);
    \Aliyun\Core\Profile\DefaultProfile::addEndpoint("cn-hangzhou", "cn-hangzhou", $product, $domain);
    $acsClient= new \Aliyun\Core\DefaultAcsClient($profile);
    $request = new \Aliyun\Api\Sms\Request\V20170525\SendSmsRequest();
    //必填-短信接收号码。支持以逗号分隔的形式进行批量调用，批量上限为1000个手机号码,批量调用相对于单条调用及时性稍有延迟,验证码类型的短信推荐使用单条调用的方式
    $request->setPhoneNumbers($tel);
    //必填-短信签名
    $request->setSignName($sign);
    //必填-短信模板Code
    $request->setTemplateCode($number);
    //选填-假如模板中存在变量需要替换则为必填(JSON格式),友情提示:如果JSON中需要带换行符,请参照标准的JSON协议对换行符的要求,比如短信内容中包含\r\n的情况在JSON中需要表示成\\r\\n,否则会导致JSON在服务端解析失败
    if(!empty($data)){
        $request->setTemplateParam(json_encode($data));
    }

    //选填-发送短信流水号
    $request->setOutId("1234");
    //发起访问请求
    $acsResponse = $acsClient->getAcsResponse($request);
    return $acsResponse;
}

//每日收益
function earnings(){
    $money=db('member')->where('m_assets','>=',1)->field('m_assets,m_id,m_profit')->select();//所有用户的总资产

    $ratio=db('recharge_ratio')->field('r_profit')->find();//收益比例
    //“总资产”每天按照2%的比例（可以控制），转换为“总收益”

    foreach($money as $k=>$v){
        $res=$v['m_assets']*($ratio['r_profit']/100);//静态收益金额
        $res=round($res,2);
        $rest=$v['m_assets']-$res;//用户收益后的总资产
        $profit=$v['m_profit']+$res;//用户现有收益

        $result=db('member')->where('m_id',$v['m_id'])->update(['m_profit'=>$profit,'m_assets'=>$rest]);
        $order=time().mt_rand(1000,9999).$v['m_id'];
        $result1=db('profit_log')->insert(['p_id'=>$order,'p_user_id'=>$v['m_id'],'p_info'=>'静态收益￥'.$res,'p_money'=>$res,'p_state'=>2,'p_time'=>time()]);


    }
    echo date('Y-m-d H:i:s',time());
}
/***********递归方式获取上下级权限信息****************/
function generateTree($data){
    $items = array();
    foreach($data as $v){
        $items[$v['auth_id']] = $v;
    }
    $tree = array();
    foreach($items as $k => $item){
        if(isset($items[$item['auth_pid']])){
            $items[$item['auth_pid']]['son'][] = &$items[$k];
        }else{
            $tree[] = &$items[$k];
        }
    }
    return getTreeData($tree);
}
function getTreeData($tree,$level=0){
    static $arr = array();
    foreach($tree as $t){
        $tmp = $t;
        unset($tmp['son']);
        $tmp['level'] = $level;
        $arr[] = $tmp;
        if(isset($t['son'])){
            getTreeData($t['son'],$level+1);
        }
    }
    return $arr;
}
//代理
function agent(){
    $user=db('member')->field('m_id')->order('m_agent asc')->select();
    foreach($user as $k=>$v){
        (new \app\common\model\Agent())->agent($v['m_id']);
    }
    echo date('Y-m-d H:i:s',time());
}
/***********图片上传*******************/

function upload($type,$files,$fileType='jpg,png,gif,jpeg',$url,$img=null,$size=512000)
{
    switch ($type) {
        case 'add':
            if (!empty($_FILES[$files])) {
                $file = request()->file($files);
                // dump($file);
                if ($file) {
                    $info = $file->rule('uniqid')->validate(['size' => $size, 'ext' => $fileType])->move(ROOT_PATH . 'public' . DS . 'upload' . DS . $url);
                    //dump($info);
                    if ($info) {
                        if (!empty($img)) {
                            @unlink(ROOT_PATH . 'public' . DS . 'upload' . DS . $url . DS . $img);
                        }
                        $res = $info->getFilename();

                        return ['status' => 0, 'msg' => $res];
                    } else {
                        // 上传失败获取错误信息
                        return ['status' => 1, 'msg' => "上传失败！"];
                    }
                } else {
                    return ['status' => 1, 'msg' => "上传文件失败,超出上传文件大小！请刷新"];
                }
            } else {
                return ['status' => 1, 'msg' => "请选择要上传图片或文件！"];
            }

            break;
        case 'dele':
            $fal_img = unlink(ROOT_PATH . 'public' . DS . 'upload' . DS . $url . DS . $img);

            return $fal_img;
            break;
    }
}
